<?php
        include_once 'Header.php'
?>

<div id="contactUs">
        <h2>Need help, send us a message</h2>
                <ul>
                        <li>Telephone: 1242 252370</li>
                        <li>Email: ParcelPost@emal.com</li>
                        <li>Post Code: EX4 72D</li>
                </ul>
</div>

<?php
        include_once 'Footer.php'
?>