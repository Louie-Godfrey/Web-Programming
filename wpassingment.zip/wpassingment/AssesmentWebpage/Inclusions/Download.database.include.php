<?php   //The data to connect to the database, seperated from any main page to prevent data leaks
        $username = "s5309947";
        $password = "Dankdog101"; 
        $host = "db.bucomputing.uk";
        $port = 6612; 
        $database = $username;  